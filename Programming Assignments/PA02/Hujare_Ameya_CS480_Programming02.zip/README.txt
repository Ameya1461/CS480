
OPEN ALL THE FILES TOGERTHER FROM THE FOLDER TO RUN THE PROGRAM, EACH ALGORITHM IS IMPLMENTED SEPERATELY IN DIFFERENT .PY FILE.


Python Files: 

1. cs480_P02_A20545367 --> Main .py file
2. brute_force --> brute force algorithm implementation
3. csp --> CSP algorithm implmentation
4. csp_backtrack --> CSP backtrack algorithm implementation
5. csp_fc_mrv --> CSP with forward-checking and MRV heuristics algorithm implmentation
6. utils

.CSV Files:
1. testcase1
2. testcase2
3. testcase3
4. testcase4
5. testcase4_solution
6. testcase6
7. testcase7

Command to run the program on testcase6 and algorithm 2 -->
 python3 cs480_p02_A20545367.py 2 testcase6.csv